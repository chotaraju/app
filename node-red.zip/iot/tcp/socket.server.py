import socket

HOST = '192.168.51.157'
PORT = 4444
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print('Socket Created')

try:
    s.bind((HOST, PORT))
except socket.error:
    print('Bind Failed')

s.listen(5)
print('Socket awaiting messages')
(conn, addr) = s.accept()
print('Connected')

while True:
    data = conn.recv(1080)
    print('I sent a message back in response to: ' + data)
    reply = ' '

    if data == 'Hello':
        reply = 'Hi, back'
    elif data == 'This is important':
        reply = 'OK, I have done the important thing you have asked me!'

    elif data == 'quit':
        conn.send('Terminating')
        break
    else:
        reply = 'Unknown command'

    conn.send(reply)
    con.close()

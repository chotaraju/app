#To join two strings
s1 = "abc"
s2 = "def"
s = s1 + s2
print(s)

#To find the position of one string
s3 = "abcdefghi"
print(s3.find("def"))

#Find the length
s4 = "aabbccdd"
print(len(s4))

#Extracting the part of string
s5 = "abcdefghi"
print(s5[1:5])

#Converting String from lower to upper
s6 = "aBcDeF"
print(s6.upper())

#Converting string from upper to lower
s7 = "aBcDeF"
print(s7.lower())

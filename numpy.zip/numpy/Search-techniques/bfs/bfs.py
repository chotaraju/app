# Implement Breadth first search algorithm for Romanian map problem.

from map import romania_map, GraphProblem, breadth_first_tree_search

print("after construcing grpah - ")

print(romania_map.graph_dict)

print("------")

print("Children of Arad ", romania_map.get('Arad'))

print("distance from arad to sibiu = ",romania_map.get('Arad','Sibiu'))

print("=============== BFS Algo ====================")

romania_problem = GraphProblem('Arad','Bucharest', romania_map)

print("Keys of Arad ", romania_problem.actions( 'Arad'))

finalnode = breadth_first_tree_search(romania_problem)

print("solution of ", romania_problem.initial, " to ", romania_problem.goal, finalnode.solution())

print("path cost of final node =", finalnode.path_cost)
